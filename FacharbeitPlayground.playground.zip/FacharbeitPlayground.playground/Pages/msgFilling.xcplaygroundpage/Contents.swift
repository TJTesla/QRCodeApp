//: [Previous](@previous)

import Foundation

struct CodeModule {
	private var reserved: ModuleType
	private var color: Color
	
	init() {
		self.color = .none
		self.reserved = .data
	}
	
	init(pColor: Color, reserve: ModuleType = .data) {
		self.color = pColor
		self.reserved = reserve
	}
	
	public func isReserved() -> Bool {
		return self.reserved == .data
	}
	
	public func getPart() -> ModuleType {
		return self.reserved
	}
	
	public func getColor() -> Color {
		return self.color
	}
	
	public enum Color {
		case white, black, none
	}
}

enum ModuleType {
	case finder, separator, alignment
	case vTiming, hTiming
	case format, upVersion, lowVersion
	case data
}


var matrix = Array(repeating: Array(repeating: 0, count: 11), count: 11)
var msg = [Int]()
for i in 0 ..< 100 {
	msg.append(i)
}

// Reserved areas:
for i in 0 ..< 2 {
	for j in 0 ..< 5 {
		matrix[i][j] = -1
		matrix[9+i][j] = -1
	}
}
for i in 0 ..< 7 {
	matrix[2+i][2] = -2
}


var xPos: (left: Int, right: Int) = (matrix.count-2, matrix.count-1)
var yPos: Int = matrix.count-1
var counter = msg.count - 1
var newLine = true

enum  Direction: Int {
	case UP = -1, DOWN = 1
}
var direction: Direction = .UP

while counter < msg.count {
	if xPos.left < 0 { // Prevent index out of bounds error (Safety net)
		break
	}
	
	if matrix[yPos][xPos.right] == 0 {  // Only draw when possible
		matrix[yPos][xPos.right] = msg[counter]
		counter -= 1
	}
	if matrix[yPos][xPos.left] == 0 {
		matrix[yPos][xPos.left] = msg[counter]
		counter -= 1  // Progress to next element only when could be drawn
	}
	
	if (yPos == 0 || yPos == matrix.count-1) && !newLine {
		direction = direction == .UP ? .DOWN : .UP
		newLine = true
		if xPos.left == 3 {  // Hit vertical timing pattern
			xPos.left -= 3
			xPos.right -= 3
			continue
		}
		xPos.left -= 2
		xPos.right -= 2
		continue
	}
	newLine = false
	yPos += direction.rawValue
}

for i in matrix {
	for j in i {
		print(String(format: "%2d", j), terminator: " ")
	}
	print("")
}

//: [Next](@next)
