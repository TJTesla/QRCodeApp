//: [Previous](@previous)

import Foundation

let a = 0b000010100110111
let b = 0b101010000010010

let c = a ^ b

print(String(c, radix: 2))

/*func padRight(toSize size: Int, message msg: String) -> String {
	var str = msg
	
	if str.count >= size {
		return str
	}
	
	for _ in 0 ..< size - str.count {
		str.insert("0", at: str.endIndex)
	}
	
	return str
}

func padLeft(toSize size: Int, message msg: String) -> String {
	var str = msg
	
	if str.count >= size {
		return str
	}
	
	for _ in 0 ..< size - str.count {
		str.insert("0", at: str.startIndex)
	}
	
	return str
}
for i in 7 ..< 11 {
	let version = i
	var str = String(version, radix: 2)
	str = padLeft(toSize: 6, message: str)
	str = padRight(toSize: 18, message: str)
	while (str.starts(with: "0")) {
		str.remove(at: str.startIndex)
	}
	let msgInt = Int(str, radix: 2) ?? 0

	var genPoly = "1111100100101"
	genPoly = padRight(toSize: str.count, message: genPoly)

	let genInt = Int(genPoly, radix: 2) ?? 2

	let xorInt = msgInt ^ genInt

	var xorStr = String(xorInt, radix: 2)

	if xorStr.count < 12 {
		xorStr = padLeft(toSize: 12, message: xorStr)
	}

	str  = String(version, radix: 2)
	str = padLeft(toSize: 6, message: str)

	xorStr.insert(contentsOf: str, at: xorStr.startIndex)

	print(i, xorStr, separator: ": ")
	print(str)
	print(xorStr)
	print("")
}
//: [Next](@next)
*/
