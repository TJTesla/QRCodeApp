//: [Previous](@previous)

import Foundation

let a = -1
let b = 2
print(String(format: "%2d", a))
print(String(format: "%2d", b))

//: [Next](@next)
