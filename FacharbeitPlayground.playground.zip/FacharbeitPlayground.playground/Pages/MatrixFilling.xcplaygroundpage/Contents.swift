import UIKit

let v = 7
let size = ((v-1)*4)+21
var matrix = Array(repeating: Array(repeating: CodeModule(), count: size), count: size)

struct CodeModule {
	private var reserved: Bool
	private var color: Color
	
	init() {
		self.color = .none
		self.reserved = false
	}
	
	init(pColor: Color, reserve: Bool = false) {
		self.color = pColor
		self.reserved = reserve
	}
	
	public func isReserved() -> Bool {
		return self.reserved
	}
	
	public func getColor() -> Color {
		return self.color
	}
	
	public enum Color {
		case white, black, none
	}
}

func createFormatString() -> [Int] {
	// Error Correction Level: M (0) 101000100100101
	// Masking pattern: 1: (row) % 2 == 0
	var formatString = "101000100100101"
	print(formatString)
	var returnVal = [Int]()
	for _ in 0 ..< formatString.count {
		returnVal.append( Int(String(formatString.first!))! )
		formatString.removeFirst()
	}
	return returnVal
}

func createVersionInfo(_ version: Int) -> [Int] {
	let table = ["000111110010010100", "001000010110111100", "001001101010011001", "001010010011010011"]
	// Source: https://www.thonky.com/qr-code-tutorial/format-version-tables
	var entry = table[version-7]
	var returnVal = [Int]()
	for _ in 0 ..< entry.count {
		returnVal.append( Int(String(entry.first!))! )
		entry.removeFirst()
	}
	return returnVal
}

func finderPatterns(_ pMatrix: [[CodeModule]], x: Int, y: Int) -> [[CodeModule]] {
	//var matrix = pMatrix
	for i in 0 ..< 7 {
		matrix[y][x+i] = CodeModule(pColor: .black, reserve: true)
	}
	
	matrix[y+1][x] = CodeModule(pColor: .black, reserve: true)
	for i in 1 ... 5 {
		matrix[y+1][x+i] = CodeModule(pColor: .white, reserve: true)
	}
	matrix[y+1][x+6] = CodeModule(pColor: .black, reserve: true)
	
	for j in 0 ..< 3 {
		matrix[y+2+j][x] = CodeModule(pColor: .black, reserve: true)
		matrix[y+2+j][x+1] = CodeModule(pColor: .white, reserve: true)
		for i in 2 ... 4 {
			matrix[y+2+j][x+i] = CodeModule(pColor: .black, reserve: true)
		}
		matrix[y+2+j][x+5] = CodeModule(pColor: .white, reserve: true)
		matrix[y+2+j][x+6] = CodeModule(pColor: .black, reserve: true)
	}
	
	matrix[y+5][x] = CodeModule(pColor: .black, reserve: true)
	for i in 1 ... 5 {
		matrix[y+5][x+i] = CodeModule(pColor: .white, reserve: true)
	}
	matrix[y+5][x+6] = CodeModule(pColor: .black, reserve: true)
	
	for i in 0 ..< 7 {
		matrix[y+6][x+i] = CodeModule(pColor: .black, reserve: true)
	}
	
	return matrix
}

func separator(_ pMatrix: [[CodeModule]], corner: Corner) -> [[CodeModule]] {
	//var matrix = pMatrix
	
	var horiStart: (x: Int, y: Int)
	var vertiStart: (x: Int, y: Int)
	switch corner {
		case .upperLeft:
			horiStart = (0, 7)
			vertiStart = (7, 0)
		case .upperRight:
			horiStart = (matrix.count-1-7, 7)
			vertiStart = (matrix.count-1-7, 0)
		case .lowerLeft:
			horiStart = (0, matrix.count-1-7)
			vertiStart = (7, matrix.count-7)
		default:
			horiStart = (0, 0)
			vertiStart = (0, 0)
	}
	
	for i in 0 ..< 8 {
		matrix[horiStart.y][horiStart.x+i] = CodeModule(pColor: .white, reserve: true)
	}

	for i in 0 ..< 7 {
		matrix[vertiStart.y+i][vertiStart.x] = CodeModule(pColor: .white, reserve: true)
	}
	
	return matrix
}

enum Corner: Int {
	case upperLeft = 0, upperRight, lowerLeft, lowerRight
}

func placeAlignmentPattern(_ pMatrix: [[CodeModule]], pos p: (Int, Int)) -> [[CodeModule]] {
	//var matrix = pMatrix
	
	if matrix[p.1+2][p.0+2].isReserved() {
		return pMatrix
	}
	
	for i in 0 ..< 5 {
		matrix[p.1][p.0+i] = CodeModule(pColor: .black, reserve: true)
	}
	
	matrix[p.1+1][p.0] = CodeModule(pColor: .black, reserve: true)
	for i in 1 ... 3 {
		matrix[p.1+1][p.0+i] = CodeModule(pColor: .white, reserve: true)
	}
	matrix[p.1+1][p.0+4] = CodeModule(pColor: .black, reserve: true)
	
	matrix[p.1+2][p.0+0] = CodeModule(pColor: .black, reserve: true)
	matrix[p.1+2][p.0+1] = CodeModule(pColor: .white, reserve: true)
	matrix[p.1+2][p.0+2] = CodeModule(pColor: .black, reserve: true)
	matrix[p.1+2][p.0+3] = CodeModule(pColor: .white, reserve: true)
	matrix[p.1+2][p.0+4] = CodeModule(pColor: .black, reserve: true)
	
	matrix[p.1+3][p.0] = CodeModule(pColor: .black, reserve: true)
	for i in 1 ... 3 {
		matrix[p.1+3][p.0+i] = CodeModule(pColor: .white, reserve: true)
	}
	matrix[p.1+3][p.0+4] = CodeModule(pColor: .black, reserve: true)
	
	for i in 0 ..< 5 {
		matrix[p.1+4][p.0+i] = CodeModule(pColor: .black, reserve: true)
	}
	
	return matrix
}

func alignmentPattern(_ pMatrix: [[CodeModule]], _ version: Int) -> [[CodeModule]] {
	if version == 1 {
		return pMatrix
	}
	
	let pos: (Int, Int, Int)
	if version == 2 {
		pos = (6, 18, -1)
	} else if version == 7 {
		pos = (6, 22, 38)
	} else { // Version 8
		pos = (6, 24, 42)
	}
	var matrix = pMatrix
	
	if (pos.2 == -1) {
		matrix = placeAlignmentPattern(matrix, pos: (pos.1-2, pos.1-2))
	} else {
		matrix = placeAlignmentPattern(matrix, pos: (pos.1-2, pos.0-2))
		matrix = placeAlignmentPattern(matrix, pos: (pos.0-2, pos.1-2))
		matrix = placeAlignmentPattern(matrix, pos: (pos.1-2, pos.1-2))
		matrix = placeAlignmentPattern(matrix, pos: (pos.2-2, pos.1-2))
		matrix = placeAlignmentPattern(matrix, pos: (pos.1-2, pos.2-2))
		matrix = placeAlignmentPattern(matrix, pos: (pos.2-2, pos.2-2))
	}
	
	return matrix
}

func timingPatterns(_ pMatrix: [[CodeModule]]) -> [[CodeModule]]{
	var matrix = pMatrix
	// Horizontal
	var xStart = 8, yStart = 6
	for i in 0 ..< pMatrix.count-16 {
		if i % 2 == 0 {
			matrix[yStart][xStart+i] = CodeModule(pColor: .black, reserve: true)
		} else {
			matrix[yStart][xStart+i] = CodeModule(pColor: .white, reserve: true)
		}
	}
	// Vertical
	xStart = 6; yStart = 8
	for i in 0 ..< pMatrix.count-16 {
		if i % 2 == 0 {
			matrix[yStart+i][xStart] = CodeModule(pColor: .black, reserve: true)
		} else {
			matrix[yStart+i][xStart] = CodeModule(pColor: .white, reserve: true)
		}
	}
	
	return matrix
}

func formatStringAndVersionInformation(_ pMatrix: [[CodeModule]], _ version: Int) -> [[CodeModule]] {
	var matrix = pMatrix
	
	let formatString = createFormatString()
		
	for i in 0 ..< 6 {
		if formatString[i] == 1 {
			matrix[8][i] = CodeModule(pColor: .black, reserve: true)
		} else {
			matrix[8][i] = CodeModule(pColor: .white, reserve: true)
		}
		
	}
	for i in 0 ..< 6 {
		if formatString[14-i] == 1 {
			matrix[i][8] = CodeModule(pColor: .black, reserve: true)
		} else {
			matrix[i][8] = CodeModule(pColor: .white, reserve: true)
		}
	}
	
	matrix[8][7] = CodeModule(pColor: (formatString[6] == 1 ? .black : .white), reserve: true)
	matrix[8][8] = CodeModule(pColor: (formatString[7] == 1 ? .black : .white), reserve: true)
	matrix[7][8] = CodeModule(pColor: (formatString[8] == 1 ? .black : .white), reserve: true)
	for i in 0 ..< 7 {
		matrix[(4*version)+10+i][8] = CodeModule(pColor: (formatString[15-9-i] == 1 ? .black : .white), reserve: true)
	}
	for i in 0 ..< 8 {
		matrix[8][(4*version)+9+i] = CodeModule(pColor: (formatString[7+i] == 1 ? .black : .white), reserve: true)
	}
		
	if (version < 7) {
		return matrix
	}
	
	var versionInfo = createVersionInfo(version)
	versionInfo.reverse()
	
	let start = (4*version) + 6
	var counter = 0
	for i in 0 ..< 6 {
		for j in 0 ..< 3 {
			matrix[start+j][i] = CodeModule(pColor: (versionInfo[counter] == 1 ? .black : .white), reserve: true)
			matrix[i][start+j] = CodeModule(pColor: (versionInfo[counter] == 1 ? .black : .white), reserve: true)
			counter += 1
		}
	}
	
	return matrix
}

matrix = finderPatterns(matrix, x: 0, y: 0)
matrix = finderPatterns(matrix, x: size-7, y: 0)
matrix = finderPatterns(matrix, x: 0, y: size-7)

matrix = separator(matrix, corner: .upperLeft)
matrix = separator(matrix, corner: .upperRight)
matrix = separator(matrix, corner: .lowerLeft)

matrix = alignmentPattern(matrix, v)

matrix = timingPatterns(matrix)

matrix[(v*4)+9][8] = CodeModule(pColor: .black, reserve: true)

matrix = formatStringAndVersionInformation(matrix, v)

for i in 0 ..< matrix.count {
	for j in 0 ..< matrix[i].count {
		if matrix[i][j].getColor() == .black {
			print("1", terminator: " ")
		} else if matrix[i][j].getColor() == .white {
			print("0", terminator: " ")
		} else {
			print(".", terminator: " ")
		}
	}
	print("", terminator: "\n")
}
